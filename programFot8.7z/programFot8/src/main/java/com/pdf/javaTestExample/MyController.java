package com.pdf.javaTestExample;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class MyController {

    @GetMapping("/example")
    public String exampleMethod() {
        throw new NullPointerException("Example exception occurred");
    }
}