package com.pdf.javaTestExample;

import java.util.Collections;
import java.util.TreeMap;

public class TestTreeComparable {
	
	public static void main(String args[]) {
		TreeMap<Employee2,Integer>map=new TreeMap<>();
		map.put(new Employee2("shadma",22), 122);
		map.put(new Employee2("sa",2), 13);
		map.put(new Employee2("khan",9), 124);

		map.forEach((k,v)->System.out.println(k +":" +v));
	}

}
