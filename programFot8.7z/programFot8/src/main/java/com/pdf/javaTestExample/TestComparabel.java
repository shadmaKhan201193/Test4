package com.pdf.javaTestExample;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class TestComparabel {
	
	 public static void main(String args[]) {
		 
		 List<Employee> emp=new ArrayList<>();
		 emp.add(new Employee("khan"));
		 emp.add(new Employee("shadma"));
		 emp.add(new Employee("java"));
		 
		 Collections.sort(emp);
		  for (Employee employee : emp) {
	            System.out.println(employee.getName());
	        }
		 
		 
	 }
	
}