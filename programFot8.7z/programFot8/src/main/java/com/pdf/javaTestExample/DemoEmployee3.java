package com.pdf.javaTestExample;

import java.util.Map;
import java.util.TreeMap;

public class DemoEmployee3 {
	
	public static void main(String args[]) {
		
		Map<Emoloyee3,String> map=new TreeMap<>();
		Emoloyee3 e=new Emoloyee3("1","Somnath",10);
		Emoloyee3 e1=new Emoloyee3("3","Somnath",10);
		Emoloyee3 e2=new Emoloyee3("4","Somnath",10);
		map.put(e,"1");
		map.put(e1,"1");
		map.put(e2,"1");
		System.out.println(map.size());
	}

}
