package com.pdf.javaTestExample;

import java.time.LocalDate;
import java.time.Period;
import java.util.Set;
import java.util.TreeSet;

public class FilterEmployeeWithExperience {
	
	public static void main(String args[]) {
		
		
		Set<Employee4>employee=new TreeSet<>();
		employee.add(new Employee4("sahdma",LocalDate.of(2016, 5, 14)));
		employee.add(new Employee4("sahdma",LocalDate.of(2016, 5, 14)));
		employee.add(new Employee4("yogita",LocalDate.of(2015, 5, 14)));
		employee.add(new Employee4("arti",LocalDate.of(2018, 5, 14)));
		
		for(Employee4 employee2:employee){
			
			LocalDate currentDate=LocalDate.now();
			Period period=Period.between(employee2.getDateOfJoining(), currentDate);
			Integer year=period.getYears();
			System.out.println(employee2.getName()+" have "+ year +"   " );
		}
	
		
	}

}
