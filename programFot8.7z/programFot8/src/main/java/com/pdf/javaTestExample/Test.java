package com.pdf.javaTestExample;

import java.util.Arrays;
import java.util.List;

public class Test  {
	
	
	
	public static void main(String args[]) {
	

        List<Integer> listOfIntegers = Arrays.asList(45, 12, 56, 15, 24, 75, 31, 89);
        
        
		
	
}

	

}
