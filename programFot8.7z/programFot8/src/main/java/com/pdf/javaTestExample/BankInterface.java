package com.pdf.javaTestExample;



public interface BankInterface {
	public void test();
}
