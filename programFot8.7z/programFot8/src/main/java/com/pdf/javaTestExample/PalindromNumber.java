package com.pdf.javaTestExample;

public class PalindromNumber {

	public static void main(String[] args) {

		Integer number=545;
		
		
		
	}

}
