package com.pdf.javaTestExample;

import java.util.ArrayList;
import java.util.List;

public class ChunkSplit {
	
	public static void main(String args[]) {
		
		 int[] array = {1, 2, 34, 5, 6, 7};
		int splitsize=2;
		
		 List<List<Integer>> chunks = new ArrayList<>();
	        int length = array.length;
	        int startIndex = 0;

	        while (startIndex < length) {
	            int endIndex = Math.min(startIndex + splitsize, array.length);
	            List<Integer> chunk = new ArrayList<>();
	            for (int i = startIndex; i < endIndex; i++) {
	                chunk.add(array[i]);
	            }
	            chunks.add(chunk);
	            startIndex += splitsize;
	        }

	        for (List<Integer> chunk : chunks) {
	            System.out.println(chunk);
	        }
	    
	}

}
