package com.pdf.javaTestExample;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class CharacterOccurrenceInFile {
	 public static void main(String[] args) {
	        String filePath = "C:/Users/sadma.khan.KIYA/Desktop/Test"; // Replace this with the path to your file
	        
	        final int charQuantity = 'z' - 'a';
	        int[] counter = new int[charQuantity];
	        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
	            int ch;
	            while ( (ch = reader.read()) >= 0) {
		            if (Character.isLetter(ch)) {
		                counter[Character.toLowerCase(ch) - 'a']++;
		            }
		        }
	        } catch (IOException e) {
	            System.err.println("Error reading the file: " + e.getMessage());
	        }

	        for (char c = 'a'; c < 'z'; c++) {
	            System.out.println("'" + c + "' occurs " + counter[c - 'a'] + " times");
	        }
	    }
	}

