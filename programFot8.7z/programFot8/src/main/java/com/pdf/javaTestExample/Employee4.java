package com.pdf.javaTestExample;

import java.time.LocalDate;

public class Employee4 implements Comparable<Employee4> {
	private String name;
	  private LocalDate dateOfJoining;
	  
	  
	  public  Employee4(String name,LocalDate dateOfJoining) {
			 this.name=name;
			 this.dateOfJoining=dateOfJoining;
			 
		 }
	  
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public LocalDate getDateOfJoining() {
		return dateOfJoining;
	}
	public void setDateOfJoining(LocalDate dateOfJoining) {
		this.dateOfJoining = dateOfJoining;
	}

	@Override
	public String toString() {
		return "Employee4 [name=" + name + ", dateOfJoining=" + dateOfJoining + "]";
	}

	 @Override
	    public int compareTo(Employee4 other) {
	        // Comparing based on name
	        return this.name.compareTo(other.name);
	    }
	  

}
