package com.pdf.javaTestExample;



public class Employee2 implements Comparable<Employee2> {
	 private String name;
	private Integer age;
	
	
	
	
	Employee2(String name ,Integer age){
		this.name=name;
		this.age=age;
	
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		 this.name=name;
	}
	
	
	public Integer getAge() {
		return age;
	}
	public void setAge() {
		this.age=age;
	}
	
	@Override
	public int compareTo(Employee2 o) {
		
		return this.age.compareTo(o.age);
	}
	@Override
	public String toString() {
		return "Employee2 [name=" + name + ", age=" + age + "]";
	}
	
}



























