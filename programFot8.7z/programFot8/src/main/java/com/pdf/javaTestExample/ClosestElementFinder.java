package com.pdf.javaTestExample;


public class ClosestElementFinder {
	
	 

	public static void main(String args[]) {
		int[] arr = {1, 3, 5, 7, 9};
		int target = 6;
		
		        int closest = arr[0]; 
		        for (int i = 1; i < arr.length; i++) {
		            if (Math.abs(arr[i] - target) < Math.abs(closest - target)) {  //Returns the absolute value of an int value
		                closest = arr[i];
		            }
		        }
        System.out.println(target+":"+closest+"");
		    }

	}


