package com.pdf.javaTestExample;

import java.util.Comparator;
import java.util.TreeMap;

public class TestTreeComparator implements Comparator<Employee2>{

	@Override
	public int compare(Employee2 o1, Employee2 o2) {
		return o1.getAge().compareTo(o2.getAge());  
		
	}
	 public static void main(String args[]) {
		 
		 TreeMap<Employee2, Integer> map = new TreeMap<>();
		 map.put(new Employee2("shadma",22), 122);
		map.put(new Employee2("sa",2), 13);
		map.put(new Employee2("khan",9), 124);
		map.forEach((k,v)->System.out.println(k +": "+v));
		 
	 }
	
	
//	private String name;
//	private Integer age;
//	
//	
//	TestTreeComparator(String name ,Integer age){
//		this.name=name;
//		this.age=age;
//	}
//		@Override
//		public String toString() {
//			return "Employee2 [name=" + name + ", age=" + age + "]";
//		}
//	public static void main(String args[]) {
//		TreeMap<TestTreeComparator, Integer> map = new TreeMap<>(new Comparator<TestTreeComparator>() {
//            @Override
//            public int compare(TestTreeComparator e1, TestTreeComparator e2) {
//              if(e1.age<e2.age) {
//            	return 1;
//              }
//              else if(e1.age>e2.age) {
//            	  return -1;  
//              }
//              return 0;
//            }
//        });
//		map.put(new TestTreeComparator("shadma",22), 122);
//		map.put(new TestTreeComparator("sa",2), 13);
//		map.put(new TestTreeComparator("khan",9), 124);
//		map.forEach((k,v)->System.out.println(k +": "+v));
//	}

}
