package com.pdf.javaTestExample;

import java.util.Comparator;
import java.util.TreeMap;

public class Emp {
	private String name;
	private Integer age;
	
	
	
	
	Emp(String name ,Integer age){
		this.name=name;
		this.age=age;
	}
		@Override
		public String toString() {
			return "Employee2 [name=" + name + ", age=" + age + "]";
		}
	

	
	public static void main(String args[]) {
		TreeMap<Employee2, Integer> map = new TreeMap<>(new Comparator<Employee2>() {
            @Override
            public int compare(Employee2 e1, Employee2 e2) {
          
                return Integer.compare(e1.getAge(), e2.getAge());
            }
        });	
		
		
		
		
	}

}
