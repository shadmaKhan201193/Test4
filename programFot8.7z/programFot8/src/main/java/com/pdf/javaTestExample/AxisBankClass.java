package com.pdf.javaTestExample;

import org.springframework.stereotype.Service;

@Service
public class AxisBankClass implements BankInterface {

	@Override
	public void test() {
		System.out.println("inside AxisBankClass test method");

	}

}
