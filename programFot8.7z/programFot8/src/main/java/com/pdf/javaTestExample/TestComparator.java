package com.pdf.javaTestExample;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class TestComparator implements Comparator<Student> {
	

	@Override
	public int compare(Student o1, Student o2) {
		
		return Integer.compare(o1.getAge(), o2.getAge());
	}
	
	public static void main(String args[]) {
		
		List<Student>stu=new ArrayList<>();
		stu.add(new Student("java",10));
		stu.add(new Student("khan",5));
		stu.add(new Student("shadma",2));
		
		Collections.sort(stu,new TestComparator());
		
		for(Student student:stu) {
			   System.out.println(student.getName() + " - " + student.getAge());
		}

		
	}

	

}
