package com.pdf.javaTestExample;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class DuplicateNumberPrint {

public static void main(String[] args) {
//	   List<Integer>data=Arrays.asList(12,32,25,11,43,12,11);
//
//       List<Integer> duplicates = data.stream()
//               .filter(e -> data.indexOf(e) != data.lastIndexOf(e)) // Filter elements that have duplicates
//               .distinct() // Remove duplicates from the list of duplicates
//               .collect(Collectors.toList());
//
//       System.out.println("Duplicate elements in the list are: " + duplicates);
       
       List<Integer> data = Arrays.asList(12, 32, 25, 11, 43, 12, 11);

       List<Integer> duplicates = new ArrayList<>();
       for (int i = 0; i < data.size(); i++) {
           int currentElement = data.get(i);
           for (int j = i + 1; j < data.size(); j++) {
               if (currentElement == data.get(j) && !duplicates.contains(currentElement)) {
                   duplicates.add(currentElement);
                   break; // No need to check for duplicates once found
               }
           }
       }
     data.stream().filter(e -> data.indexOf(e) != data.lastIndexOf(e)).forEach(System.out::println);

      // System.out.println("Duplicate elements in the list are: " + duplicates);
   }
       
       // 12-0  12-5 so ye equal nhi hai inka index
// 32-1 iska lastindex bhi 1 and index same hai 

       
}

