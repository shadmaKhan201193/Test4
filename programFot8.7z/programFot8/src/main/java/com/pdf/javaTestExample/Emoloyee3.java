package com.pdf.javaTestExample;

import java.util.Objects;

public class Emoloyee3 implements Comparable<Emoloyee3> {
	private String id;
	private String name;
	private Integer age;
	
	Emoloyee3(String id,String name,Integer age){
		this.id=id;
		this.name=name;
		this.age=age;
	}
	
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Integer getAge() {
		return age;
	}

	public void setAge(Integer age) {
		this.age = age;
	}

	@Override
	public int compareTo(Emoloyee3 o) {
		//return 0;
		return this.id.compareTo(o.id);
	}
	
	
	public String toString() {
		return "Emoloyee3{id='"+id+"',name='"+name+"',age='"+age+" }";
	}

	
	
	
}
