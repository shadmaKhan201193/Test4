package com.pdf.javaTestExample;

public class ImmutableClass {
	final String name ;

	ImmutableClass(String name){
		 this.name=name;
	 }
		public String getName() {
			return name;
		}
		
		public void setName() {
			this.name=name;
		}
		
		public static void main(String[] args) {
			ImmutableClass t=new ImmutableClass("shadam");
			 
			System.out.println("Pancard Number: " + t.getName());  
		}
}
