package com.pdf.patterns;

public class Patterns11 {

	public static void main(String[] args) {
		 int rowCount = 1;
		for(int i=9;i>=1;i--) {
			
			for(int s=1;s<=i*2;s++) {
				System.out.print(" ");
			}
			
			for(int j=1;j<=rowCount;j++) {
				System.out.print(j+ " ");
			}
			for(int k=rowCount-1;k>=1;k--) {
				System.out.print(k+ " ");
			}
			rowCount++;
			System.out.println();
		
			
		}
		
	}

}


   
