package com.pdf.patterns;

public class Patterns10 {

	public static void main(String[] args) {
		   int rowCount = 1;	
    for(int i=9;i>=1;i--) {
    	
    	for(int s=1;s<=i;s++) {
    		System.out.print(" ");
    	}
    	for(int j=1;j<=rowCount;j++) {
    		System.out.print(" "+ j);
    	}
    	
    	 System.out.println();
    	    rowCount++;
      } 
   
    
	}

}


