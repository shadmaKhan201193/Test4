package com.pdf.patterns;

public class Patterns12 {

	public static void main(String[] args) {
		int rowCount=9;
		for (int i = 1; i <= 9; i++) {
			for (int s = 1; s <= i * 2; s++) {
				System.out.print(" ");
			}
			for(int j=1;j<=rowCount;j++) {
				System.out.print(j+ " ");
			}
			for(int k=rowCount-1;k>=1;k--) {
				System.out.print(k+ " ");
			}
			System.out.println();
			rowCount--;
		}

	}

}
