package com.pdf.patterns;

import java.util.Map;
import java.util.Map.Entry;
import java.util.function.Function;
import java.util.stream.Collectors;

public class Test {

	public static void main(String[] args) {
		int count=9;
		for(int i=1;i<=9;i++) {
			for(int s=1;s<=2*i;s++) {
				System.out.print(" ");
			}
			for(int j=1;j<=count;j++) {
				System.out.print(j+" ");
			}
			for(int k=count-1;k>=1;k--) {
				System.out.print(k+" ");
			}
			count--;
			System.out.println();
		}
	}
}