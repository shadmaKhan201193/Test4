package com.pdf.java8Programs;

public class armstrong {
public static void main(String[] args) {
		
    int n = 153;
    int sumOfCubes = String.valueOf(n).chars()
            .map(Character::getNumericValue)
            .map(num -> num * num * num)
            .sum();

    String result = (sumOfCubes == n) ? "Number is Armstrong." : "Number is not Armstrong.";
    System.out.println(result);

//		int a,c = 0;
//		int n=153;
//		int temp=n;
//		while(n>0) {
//			a=n%10;
//			n=n/10;
//			c=c+(a*a*a);
//		}
//		if(temp==c) {
//			System.out.println("number is armstrom");
//		}
//		else
//			System.out.println("number not armstrom");
//	}

}
}
