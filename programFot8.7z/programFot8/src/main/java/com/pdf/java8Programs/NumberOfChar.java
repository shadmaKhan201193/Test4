package com.pdf.java8Programs;

import java.util.HashMap;

public class NumberOfChar {

	public static void main(String[] args) {
	    String str="shadmaaa";
	    get(str);
	   
	}

	public static void get(String inpuString) {
		HashMap<Character, Integer> countmap = new HashMap<>();
		char[] str = inpuString.toCharArray();
		for(char c :str) {
			if(countmap.containsKey(c)) {
				countmap.put(c, countmap.get(c)+1);
			}else {
				countmap.put(c, 1);
			}
		}
		System.out.println("number of each character in string " +countmap);
	}
}



