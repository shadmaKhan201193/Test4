package com.pdf.java8Programs;

import java.util.stream.IntStream;

public class SumOfFirst10NaturalNum {
	public static void main(String[] args) {

		
		int sum=IntStream.range(1, 11).sum();
		System.out.println(sum);
}
}