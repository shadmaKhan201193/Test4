package com.pdf.java8Programs;

import java.util.stream.IntStream;

public class IsPrime {
	public static void main(String[] args) {
	  int i = 7;
      
      boolean isPrime = isPrime(i);
      
      System.out.println(i + (isPrime ? " is " : " is not ") + "a prime number.");
  }

  public static boolean isPrime(int n) {
      return n > 1 && IntStream.range(2, n)
                              .noneMatch(i -> n % i == 0);
	}
	
	}


