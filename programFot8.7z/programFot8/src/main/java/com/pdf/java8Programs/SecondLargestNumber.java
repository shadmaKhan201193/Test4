package com.pdf.java8Programs;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.stream.IntStream;
import java.util.stream.Stream;

public class SecondLargestNumber {
	
	public static void main(String[] args) {
		
		
		List<Integer>data=Arrays.asList(90,56,12,3,65);
		int s=data.stream().sorted(Comparator.reverseOrder()).skip(1).findFirst().get();
       System.out.println(s);
	}

}
