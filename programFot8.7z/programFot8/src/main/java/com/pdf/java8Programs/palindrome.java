package com.pdf.java8Programs;

public class palindrome {
	public static void main(String[] args) {
		
		int r,sum= 0;
		int n=454;
		int temp=n;
		while(n>0) {
			r=n%10;
			sum=(sum*10)+r;
			n=n/10;
			
		}
		if(temp==sum) {
			System.out.println("number is palindrom");
		}
		else
			System.out.println("number not palindrom");
	}
}
