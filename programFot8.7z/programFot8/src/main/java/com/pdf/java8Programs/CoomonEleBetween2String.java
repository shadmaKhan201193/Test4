package com.pdf.java8Programs;

import java.util.List;
import java.util.stream.Collectors;

public class CoomonEleBetween2String {
	public static void main(String[] args) {
	String str1 = "DACD";
    String str2 = "CDDS";

    List<Character> list1 = str1.chars().mapToObj(c -> (char) c).collect(Collectors.toList());
    List<Character> list2 = str2.chars().mapToObj(c -> (char) c).collect(Collectors.toList());
    
    
    list1.retainAll(list2);


    list1.forEach(System.out::print);
}
}