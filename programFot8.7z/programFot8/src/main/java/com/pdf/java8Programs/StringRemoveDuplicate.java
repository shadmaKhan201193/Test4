package com.pdf.java8Programs;

import java.util.stream.Collectors;

public class StringRemoveDuplicate {

	public static void main(String[] args) {
		 String str = "addadadcb";
	        
	        String result = str.chars()
	                        .distinct()
	                        .mapToObj(c -> String.valueOf((char) c))
	                        .sorted()
	                        .collect(Collectors.joining());
	        
	        System.out.println(result);
	}

}
