package com.pdf.java8Programs;

import java.util.Arrays;
import java.util.Comparator;

public class MaxNumber {
	
	public static void main(String[] args) {

		  int[] a = new int[] {2, 4, 3, 12};
	        int max = Arrays.stream(a).boxed().max(Comparator.naturalOrder()).get();
	        System.out.println(max); 
		
		
	}

}
