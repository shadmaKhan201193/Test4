package com.pdf.java8Programs;

import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class ReverseStringIn8 {
	public static void main(String[] args) {
        String str = "hello";
        String reversed = IntStream.range(0, str.length())
                                   .mapToObj(i -> str.charAt(str.length() - 1 - i))
                                   .map(String::valueOf)
                                   .collect(Collectors.joining());
        System.out.println("Reversed string: " + reversed);
    }
}
