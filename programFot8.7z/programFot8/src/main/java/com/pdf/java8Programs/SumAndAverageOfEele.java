package com.pdf.java8Programs;

import java.util.Arrays;
import java.util.stream.IntStream;

public class SumAndAverageOfEele {
	public static void main(String[] args) {

        int[] a = new int[] {45, 12, 56, 15, 24, 75, 31, 89};

       int sum= Arrays.stream(a).sum();
      Double d= Arrays.stream(a).average().getAsDouble();
      System.out.println(sum);
      System.out.println(d);
		
	}
}
