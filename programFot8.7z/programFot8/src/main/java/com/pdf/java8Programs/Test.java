package com.pdf.java8Programs;

import java.util.Arrays;
import java.util.List;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import java.security.NoSuchAlgorithmException;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import java.security.Key;
class Test {

    private static final String ALGORITHM = "AES";
    private static final String KEY = "mysecretkey12345";

    public static void main(String[] args) {
        String originalString = "Hello, world!";
        System.out.println("Original String: " + originalString);

        try {
            byte[] encryptedBytes = encrypt(originalString);
            String encryptedString = DatatypeConverter.printBase64Binary(encryptedBytes);
            System.out.println("Encrypted String: " + encryptedString);

            String decryptedString = decrypt(encryptedBytes);
            System.out.println("Decrypted String: " + decryptedString);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static byte[] encrypt(String plainText) throws Exception {
        Key key = generateKey();
        Cipher cipher = Cipher.getInstance(ALGORITHM);
        cipher.init(Cipher.ENCRYPT_MODE, key);
        return cipher.doFinal(plainText.getBytes());
    }

    public static String decrypt(byte[] encryptedBytes) throws Exception {
        Key key = generateKey();
        Cipher cipher = Cipher.getInstance(ALGORITHM);
        cipher.init(Cipher.DECRYPT_MODE, key);
        byte[] decryptedBytes = cipher.doFinal(encryptedBytes);
        return new String(decryptedBytes);
    }

    private static Key generateKey() {
        return new SecretKeySpec(KEY.getBytes(), ALGORITHM);
    }
}


}





