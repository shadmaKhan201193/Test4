package com.pdf.java8Programs;

public class ReverseEachWordOfString {

	public static void main(String[] args) {

		String revwords="";
        String str = "Java Concept Of The Day";

        String[] array=str.split(" ");
        for(int j=0;j<array.length;j++) {
        	String word = array[j];
        
        for(int i=word.length()-1;i>=0;i--) {
        	revwords += word.charAt(i);
        }
        revwords +=" "; 
	}
        System.out.println(revwords);
	}

}
