package com.pdf.java8Programs;

import java.util.Arrays;
import java.util.List;

public class SumOfInteger {
public static void main(String[] args) {
		
	List<String>str=Arrays.asList("A","B","1","3");
	//int sim = str.stream().filter(i->i.matches("\\d+")).mapToInt(Integer::parseInt).map(i->i*i).sum();
	
	//int sim = str.stream().filter(i->i.matches("\\d+")).mapToInt(Integer::parseInt).sum();
	
	String sim = str.stream().filter(i->i.matches("\\d+")).
	
	
	
		
	}

}
