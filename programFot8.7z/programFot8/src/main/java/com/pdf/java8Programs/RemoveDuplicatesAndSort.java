package com.pdf.java8Programs;

import java.util.stream.Collectors;

public class RemoveDuplicatesAndSort {

	public static void main(String[] args) {

	    	 String input = "cccbbbddaaaa";
       
    	 String result= input.chars()
                .distinct()
                .sorted()
                .mapToObj(ch -> String.valueOf((char) ch))
                .collect(Collectors.joining());
        
        System.out.println("Unique characters in alphabetical order: " + result);
    }
}



