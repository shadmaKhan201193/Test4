package com.pdf.java8Programs;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

public class RepeatedNumberElements {
	public static void main(String args[]) {
		

	 List<Integer> data = Arrays.asList(2,3,5,8,8,3,2);
	 
	Map<Integer,Long> da	 =data.stream().collect(Collectors.groupingBy(Function.identity(),Collectors.counting()));
	da.forEach((k,v)->System.out.println(k +":" + v));
}
}