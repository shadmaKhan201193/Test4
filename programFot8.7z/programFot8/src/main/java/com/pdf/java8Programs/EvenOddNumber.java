package com.pdf.java8Programs;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class EvenOddNumber {
	 public static void main(String[] args) {
	
    List<Integer> listOfIntegers = Arrays.asList(71, 18, 42, 21, 67, 32, 95, 14, 56, 87);
    List<Integer> evenNumbers= listOfIntegers.stream().filter(i->i%2==0).collect(Collectors.toList());
    
      System.out.println("Even Numbers: " + evenNumbers);
      
      
      List<Integer>listodd=Arrays.asList(71, 18, 42, 21, 67, 32, 95, 14, 56, 87);
      
      List<Integer>odddata=listodd.stream().filter(i->i%2 !=0).collect(Collectors.toList());
      System.out.println(odddata);
      
	 }
	 
	 
	 
	 
}
