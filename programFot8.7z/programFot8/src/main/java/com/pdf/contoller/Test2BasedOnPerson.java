package com.pdf.contoller;



public class Test2BasedOnPerson {

	public  static void main(String args[]) {
	
	     Person p=new Person("shadma",3);
	
}
}