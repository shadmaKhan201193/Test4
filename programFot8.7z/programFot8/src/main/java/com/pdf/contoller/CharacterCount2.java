package com.pdf.contoller;

import java.util.Arrays;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.IntStream;

	public class CharacterCount2 {
	    public static void main(String[] args) {
	        String inputString = "java is very cool language cool is java";
	        String[] str=inputString.split(" ");
	        String substringToCount = inputString;  
	        List<String> languages = Arrays.asList("Java", "Python", "C++", "JavaScript", "Ruby");

	        languages.stream()
            .filter(lang -> lang.length() > 3)
            .map(String::toUpperCase)
            .forEach(System.out::println);
}
	        
	      
	    

	    private static long countSubstring(String input, String substring) {
	        Pattern pattern = Pattern.compile(substring);
	        Matcher matcher = pattern.matcher(input);

	        return IntStream.range(0, input.length() - substring.length() + 1)
	                .filter(i -> matcher.region(i, i + substring.length()).lookingAt())
	                .count();
	    }
	}


