package com.pdf.contoller;

public class ReverseCount {
	public static void main(String args[])
	{
	int[] value= {1 ,1, 3 ,2 ,4, 3, 2, 2};
	
	
	for(int i=1;i<value.length-1;i++) {
		int leftside=0;
		int righttside=0;
		for(int j=0;j<i;j++){
			leftside+=value[j];
		}
		for(int k=i+1;k<value.length;k++) {
			
			righttside+=value[k];
		}
		
		
		if(leftside==righttside) {
			System.out.println(leftside);
		}
	}
	

}
}