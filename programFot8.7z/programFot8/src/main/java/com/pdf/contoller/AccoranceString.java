package com.pdf.contoller;

public class AccoranceString {

	
	public static String  getvalue(String string,Integer rota) {
		
		String s1=string.substring(0, rota);
		
		String s=string.substring(rota, string.length());
		String mainstr=s+""+s1;
		
		return mainstr;
		
	}
	
	public static void main(String args[]) {
		String str=	getvalue("shadma",2);
		System.out.println(str);
	}
}
