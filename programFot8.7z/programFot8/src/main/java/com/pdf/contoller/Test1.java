package com.pdf.contoller;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class Test1 {
	public  static void main(String args[]) {
		
		
		
		
		List<String> G7 = Arrays.asList("USA", "Japan", "France", "Germany", "Italy", "","Canada");
		//List<String> data=G7.stream().filter(x->!x.isEmpty()).collect(Collectors.toList());
		
		List<String> data=G7.stream().map(x->x.toUpperCase()).collect(Collectors.toList());
        System.out.println(data);
	}

}
