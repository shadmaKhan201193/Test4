package com.pdf.contoller;



public class ArrayQuestion {
	
	
	
	  public static int findEqualSumIndex(int[] arr) {
	        int n = arr.length;

	        for (int i = 1; i < n - 1; i++) {
	            int leftSum = 0;
	            int rightSum = 0;

	            for (int j = 0; j < i; j++) {
	                leftSum += arr[j];
	            }

	            for (int k = i + 1; k < n; k++) {
	                rightSum += arr[k];
	            }

	            if (leftSum == rightSum) {
	                return i;
	            }
	        }

	        return -1;  // Return -1 if no such index is found
	    }
	  public static void main(String[] args) {
	 int[] array = {1, 1, 3, 2, 4, 3, 2, 2};
     int resultIndex = findEqualSumIndex(array);

     if (resultIndex != -1) {
         System.out.println("Index: " + resultIndex + ", Element: " + array[resultIndex]);
     } else {
         System.out.println("No such index found.");
     }
 }
}
