package com.pdf.contoller;

import java.lang.reflect.Field;
import java.lang.reflect.Method;

public class ReflactionDemo {
	
	public static void main(String args[]) {
		
		Customer custome=new Customer();
		
		Field[] filed=custome.getClass().getDeclaredFields();
		for(Field  value:filed) {
			
			System.out.println(value.getName());
		}
		
		
		Method[] method=custome.getClass().getDeclaredMethods();
      for(Method  value:method) {
			
			System.out.println(value.getName());
		}
		
	}
}
