package com.pdf.contoller;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class OddEvenFilter {
	  public static void main(String[] args) {
	        // Generate a list of a million numbers
	        List<Integer> numbers = IntStream.rangeClosed(1, 1_000_000).boxed().collect(Collectors.toList());

	        // Use Stream API to filter even and odd numbers
	        List<Integer> evenNumbers = numbers.stream().filter(n -> n % 2 == 0).collect(Collectors.toList());
	        List<Integer> oddNumbers = numbers.stream().filter(n -> n % 2 != 0).collect(Collectors.toList());

	        // Print results or perform further operations
	        System.out.println("Even numbers: " + evenNumbers);
	        System.out.println("Odd numbers: " + oddNumbers);
	    }
}
