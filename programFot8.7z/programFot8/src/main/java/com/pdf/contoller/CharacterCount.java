package com.pdf.contoller;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class CharacterCount {
    public static void main(String[] args) {
        String inputString = "java is very cool language cool is java";
        String substringToCount = "cool";

        long count = countSubstring(inputString, substringToCount);

        System.out.println("The substring \"" + substringToCount + "\" appears " + count + " times.");
    }

    private static long countSubstring(String input, String substring) {
        Pattern pattern = Pattern.compile(substring);
        Matcher matcher = pattern.matcher(input);

        long count = 0;
        while (matcher.find()) {
            count++;
        }

        return count;
    }
}
