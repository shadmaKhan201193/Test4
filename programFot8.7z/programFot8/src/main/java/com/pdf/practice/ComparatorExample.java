package com.pdf.practice;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class ComparatorExample implements Comparator<Employee> {
	
	@Override
	public int compare(Employee e1, Employee e2) {
		
		int flage=e1.getName().compareTo(e2.getName());
		if(flage==0) {
			flage=e1.getAge()-e2.getAge();
		}
		return flage;
	}
	
	
	public static void main(String args[]) {

		
		List<Employee>employee=new ArrayList<>();
		
		employee.add(new Employee(25,"shadma","kayan"));
		employee.add(new Employee(24,"shadma","shahad"));
		employee.add(new Employee(20,"naaz","thana"));
	
		Collections.sort(employee,new ComparatorExample());
	     System.out.println(employee);
		
		
	}

	

}
