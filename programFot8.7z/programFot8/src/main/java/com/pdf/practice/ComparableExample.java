package com.pdf.practice;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class ComparableExample implements Comparator<Employee>{
	
	@Override
	public int compare(Employee e1, Employee e2) {
		int flag =e1.getName().compareTo(e2.getName());
		if(flag==0) {
			flag=e1.getAge()-e2.getAge();
		}
		return flag;
	}
	
	public static void main(String args[]) {
		List<Employee>employee=new ArrayList<>();
		employee.add(new Employee(25,"shadam","shahad"));
		employee.add(new Employee(27,"shadam","tha"));
		employee.add(new Employee(20,"shal","kaly"));
		
		Collections.sort(employee,new ComparableExample());
        System.out.println(employee);
		
	}

	

}
