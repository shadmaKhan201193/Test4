package com.pdf.practice;


public class CloneExanmple implements Cloneable{
	int rollNo;
	String name;
	
	CloneExanmple(int rollNo,String name){
		this.rollNo=rollNo;
		this.name=name;
	}
	
	public Object clone() throws CloneNotSupportedException{
		return super.clone();
	}
	
	public static void main(String args[]) {
		try {
			CloneExanmple emp=new CloneExanmple(12,"shadma");
			CloneExanmple empCopy=(CloneExanmple)emp.clone();
			System.out.println(emp.rollNo  +" "+ emp.name);
			System.out.println(empCopy.rollNo  +" "+ empCopy.name);
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		
	}
	
	
	
}