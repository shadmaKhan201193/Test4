package com.pdf.practice;



public class Test2 extends Test{
	public void print(String name) {
		System.out.println("child print");
		super.print("java");
		
	}
}
