package com.pdf.practice;

public class Test {
	
	
	public void print(String name) {
		System.out.println("parent print");
	}
}
